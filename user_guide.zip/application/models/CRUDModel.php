<?php

/**
 * Model Jadwal Pembukaan dan Penutupan
 */
class CRUDModel extends My_Model
{
  function __construct(){
    parent::__construct();
  }
  
}