<?php

class M_Setoran extends CI_model{
	public function getListDatav3(){
		$this->db->select('jamaah.*, provinsi.*');
		$this->db->select('count(setoran.jumlah) as frekuensi');
		$this->db->select('avg(setoran.jumlah) as rerata');
		$this->db->select('sum(setoran.jumlah) as total');
		$this->db->from('jamaah');
		$this->db->join('provinsi', 'provinsi.id_provinsi = jamaah.id_provinsi', 'left');
		$this->db->join('setoran', 'setoran.id_jamaah = jamaah.id_jamaah', 'left');
		$this->db->group_by('setoran.id_jamaah');
		$this->db->order_by('sum(setoran.jumlah)', 'DESC');
		$res = $this->db->get();

		return $res->result_array();
	}	
}

?>