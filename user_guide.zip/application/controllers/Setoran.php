<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Setoran extends MY_Controller {	
	public function __construct(){
		parent::__construct();

		$this->vhome = 'index';
		$this->model->tableName = "setoran";
		$this->model->primaryId = "id_setoran";
		$this->formPage = 'admin/form_setoran';
		$this->listReferences = array(
			"id_provinsi" => array(
				"joinTableName" => "provinsi",
				"scope" => "left",
			)
		);

		$this->load->model("M_Setoran");
	}
	
	public function getListDataSetoran(){
		$retval = array();		

		$listFilters = $this->input->post();

		$listData = array();
		$listData = $this->M_Setoran->getListDatav3($listFilters);

		$retval['listData'] = $listData;

		echo json_encode($retval);
	}
}
